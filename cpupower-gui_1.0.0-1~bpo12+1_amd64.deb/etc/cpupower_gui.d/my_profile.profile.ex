# name: "Custom"

# CPU  Fmin   Fmax  Governor      Online
0-2    2200   2800   performance
3-5    2400   3200   ondemand
