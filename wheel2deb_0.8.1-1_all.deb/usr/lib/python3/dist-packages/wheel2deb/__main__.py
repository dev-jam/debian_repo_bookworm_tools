from wheel2deb.cli import main

main()
