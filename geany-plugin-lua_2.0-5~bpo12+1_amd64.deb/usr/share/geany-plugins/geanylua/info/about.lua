--[[
  Simple "about" box
--]]
geany.message(geany.pluginver())
