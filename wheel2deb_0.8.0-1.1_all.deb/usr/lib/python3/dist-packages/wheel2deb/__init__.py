import os

TEMPLATE_PATH = os.path.dirname(__file__) + "/templates/"
