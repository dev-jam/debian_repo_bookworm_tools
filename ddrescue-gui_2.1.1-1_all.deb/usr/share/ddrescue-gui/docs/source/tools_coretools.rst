Documentation for the core tools module in the tools package (Tools/core.py)
*****************************************************************************

.. automodule:: ddrescue_gui.Tools.core
    :members:
