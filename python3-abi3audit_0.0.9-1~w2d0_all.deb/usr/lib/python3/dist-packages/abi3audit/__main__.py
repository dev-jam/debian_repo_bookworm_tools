"""
The `python -m abi3audit` entrypoint.
"""

if __name__ == "__main__":
    from abi3audit._cli import main

    main()
