#define OSS_COMPILE_DATE "202011050136"
#define osdev_create osdev_create_202011050136
