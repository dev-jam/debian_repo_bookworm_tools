var yyjson_8h_structyyjson__ptr__ctx =
[
    [ "ctn", "yyjson_8h.html#a9fabdf4380dc8f44f9b7479b54c75dd0", null ],
    [ "old", "yyjson_8h.html#a4bd05d7a5f157f5178f97415c7ba08f7", null ],
    [ "pre", "yyjson_8h.html#ac68fb5d2b48052c8ab3368d3ef6a6b81", null ]
];