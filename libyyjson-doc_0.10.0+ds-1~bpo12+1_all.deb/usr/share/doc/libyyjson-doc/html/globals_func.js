var globals_func =
[
    [ "y", "globals_func.html", null ]
];