var yyjson_8h_structyyjson__mut__doc =
[
    [ "alc", "yyjson_8h.html#a1b6f74828e64779d450ffd0cbe61f08f", null ],
    [ "root", "yyjson_8h.html#a17d4291b05a54acc6310d16653de48b3", null ],
    [ "str_pool", "yyjson_8h.html#a11aa8b6fd06edf8fe371bae828052b39", null ],
    [ "val_pool", "yyjson_8h.html#a5607c9ba393206ad94ecd90fbeb59017", null ]
];