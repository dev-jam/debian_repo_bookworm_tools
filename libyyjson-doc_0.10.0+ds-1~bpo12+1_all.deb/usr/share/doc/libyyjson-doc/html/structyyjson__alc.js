var structyyjson__alc =
[
    [ "ctx", "structyyjson__alc.html#ae9499246c39efd68c206280de1b31f45", null ],
    [ "free", "structyyjson__alc.html#a2c770ff93f0f331bd60076eecd93661e", null ],
    [ "malloc", "structyyjson__alc.html#a83133b6b92e0fec52ec3c62538f44311", null ],
    [ "realloc", "structyyjson__alc.html#affacb85df656149df6c07880f0ecbe95", null ]
];