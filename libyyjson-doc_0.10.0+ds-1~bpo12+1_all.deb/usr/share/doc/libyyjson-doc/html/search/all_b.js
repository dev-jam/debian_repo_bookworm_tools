var searchData=
[
  ['realloc_0',['realloc',['../structyyjson__alc.html#affacb85df656149df6c07880f0ecbe95',1,'yyjson_alc']]],
  ['root_1',['root',['../yyjson_8h.html#ad22baac3e9ae0ff932b38f4257c3b800',1,'yyjson_doc::root()'],['../yyjson_8h.html#a17d4291b05a54acc6310d16653de48b3',1,'yyjson_mut_doc::root()']]]
];
