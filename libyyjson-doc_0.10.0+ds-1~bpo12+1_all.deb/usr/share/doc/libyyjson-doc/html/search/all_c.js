var searchData=
[
  ['str_5fpool_0',['str_pool',['../yyjson_8h.html#a83e0a27da01978e46f074b6bb068d9eb',1,'yyjson_doc::str_pool()'],['../yyjson_8h.html#a11aa8b6fd06edf8fe371bae828052b39',1,'yyjson_mut_doc::str_pool()']]]
];
