var searchData=
[
  ['changelog_0',['Changelog',['../md_CHANGELOG.html',1,'']]],
  ['code_1',['code',['../yyjson_8h.html#a550600110929a7030f464a460b5b62cb',1,'yyjson_read_err::code()'],['../yyjson_8h.html#ae4aa66c2b00d3173291dd48ae398b1c0',1,'yyjson_write_err::code()'],['../yyjson_8h.html#ac82ebe0c715ad673a943e784f325b538',1,'yyjson_ptr_err::code()'],['../yyjson_8h.html#a96dab43e96fd2d54e26deb4c25792ab7',1,'yyjson_patch_err::code()']]],
  ['ctn_2',['ctn',['../yyjson_8h.html#a9fabdf4380dc8f44f9b7479b54c75dd0',1,'yyjson_ptr_ctx']]],
  ['ctx_3',['ctx',['../structyyjson__alc.html#ae9499246c39efd68c206280de1b31f45',1,'yyjson_alc']]],
  ['cur_4',['cur',['../yyjson_8h.html#a7445de186190ceef09c5be6d589e6a65',1,'yyjson_arr_iter::cur()'],['../yyjson_8h.html#af15973d5bdb6b7b8ea79571220771027',1,'yyjson_obj_iter::cur()'],['../yyjson_8h.html#a2498a5bf91ec2eb7d4a00f89dc465954',1,'yyjson_mut_arr_iter::cur()'],['../yyjson_8h.html#a4fc0b10196e010a7e5e9a2cec6769904',1,'yyjson_mut_obj_iter::cur()']]]
];
