var searchData=
[
  ['_5f_5fbool_5ftrue_5ffalse_5fare_5fdefined_0',['__bool_true_false_are_defined',['../yyjson_8h.html#a665b0cc9ee2ced31785321d55cde349e',1,'yyjson.h']]]
];
