var searchData=
[
  ['obj_0',['obj',['../yyjson_8h.html#addf8b34eb1d89a54df0482acbd29872c',1,'yyjson_obj_iter::obj()'],['../yyjson_8h.html#ab5169c5637fdfc27fe10b919b78b6468',1,'yyjson_mut_obj_iter::obj()']]],
  ['old_1',['old',['../yyjson_8h.html#a4bd05d7a5f157f5178f97415c7ba08f7',1,'yyjson_ptr_ctx']]]
];
