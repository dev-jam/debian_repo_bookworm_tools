var yyjson_8h_structyyjson__doc =
[
    [ "alc", "yyjson_8h.html#ab1a7e03f48bb31760030fbdab7d6597b", null ],
    [ "dat_read", "yyjson_8h.html#a72bc53a422a133e2eba68ffa736f9e8b", null ],
    [ "root", "yyjson_8h.html#ad22baac3e9ae0ff932b38f4257c3b800", null ],
    [ "str_pool", "yyjson_8h.html#a83e0a27da01978e46f074b6bb068d9eb", null ],
    [ "val_read", "yyjson_8h.html#ac12f7aed42260b8d2ede0fded3f72167", null ]
];