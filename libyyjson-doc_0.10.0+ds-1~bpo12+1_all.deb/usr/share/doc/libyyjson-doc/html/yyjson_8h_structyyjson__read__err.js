var yyjson_8h_structyyjson__read__err =
[
    [ "code", "yyjson_8h.html#a550600110929a7030f464a460b5b62cb", null ],
    [ "msg", "yyjson_8h.html#a9044823fa7fb431019662e589d45707c", null ],
    [ "pos", "yyjson_8h.html#a87eb200779eff088b93ea0a67ab3e300", null ]
];