var yyjson_8h_structyyjson__mut__val =
[
    [ "next", "yyjson_8h.html#a172090776a18e45190c933fb3294c07c", null ],
    [ "tag", "yyjson_8h.html#a5fd1ae5bada624c9687acce330eef7aa", null ],
    [ "uni", "yyjson_8h.html#a2f30e3958bf136b4e8453a0e78b43d0f", null ]
];