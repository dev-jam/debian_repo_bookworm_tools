var yyjson_8h_structyyjson__write__err =
[
    [ "code", "yyjson_8h.html#ae4aa66c2b00d3173291dd48ae398b1c0", null ],
    [ "msg", "yyjson_8h.html#a3db87979e01ea1d86ce073b9e7218fe9", null ]
];