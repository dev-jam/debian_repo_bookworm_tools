var yyjson_8h_structyyjson__val =
[
    [ "tag", "yyjson_8h.html#ab589c80e05e4e65fa28e23acc1ee8255", null ],
    [ "uni", "yyjson_8h.html#a3a07ac3ac97c66ae9b23efeab600d013", null ]
];