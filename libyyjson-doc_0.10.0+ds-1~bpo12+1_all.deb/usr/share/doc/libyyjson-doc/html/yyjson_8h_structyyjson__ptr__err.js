var yyjson_8h_structyyjson__ptr__err =
[
    [ "code", "yyjson_8h.html#ac82ebe0c715ad673a943e784f325b538", null ],
    [ "msg", "yyjson_8h.html#a4d811ed5e9271667460dc1dc491d3295", null ],
    [ "pos", "yyjson_8h.html#a4b851ac068173fde6d305039762e33fd", null ]
];