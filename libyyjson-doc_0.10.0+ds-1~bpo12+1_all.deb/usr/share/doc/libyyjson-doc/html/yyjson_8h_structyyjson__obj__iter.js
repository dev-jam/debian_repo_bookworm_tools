var yyjson_8h_structyyjson__obj__iter =
[
    [ "cur", "yyjson_8h.html#af15973d5bdb6b7b8ea79571220771027", null ],
    [ "idx", "yyjson_8h.html#a6c2526c5ad89f0addaae26f356ecf609", null ],
    [ "max", "yyjson_8h.html#a05ac3955547a4be055542f922564ded6", null ],
    [ "obj", "yyjson_8h.html#addf8b34eb1d89a54df0482acbd29872c", null ]
];