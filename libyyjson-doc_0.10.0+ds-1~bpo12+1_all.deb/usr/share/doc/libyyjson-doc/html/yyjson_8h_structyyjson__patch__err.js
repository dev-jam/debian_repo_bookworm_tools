var yyjson_8h_structyyjson__patch__err =
[
    [ "code", "yyjson_8h.html#a96dab43e96fd2d54e26deb4c25792ab7", null ],
    [ "idx", "yyjson_8h.html#ac1584d63763ce24855df7aee5c9c5782", null ],
    [ "msg", "yyjson_8h.html#ae5741da19f51abd241bdce87a921ba4a", null ],
    [ "ptr", "yyjson_8h.html#a766102bcfc009fe568ea5655f133f753", null ]
];