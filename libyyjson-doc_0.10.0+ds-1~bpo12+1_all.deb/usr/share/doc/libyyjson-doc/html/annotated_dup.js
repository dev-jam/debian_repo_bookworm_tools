var annotated_dup =
[
    [ "yyjson_alc", "structyyjson__alc.html", "structyyjson__alc" ],
    [ "yyjson_arr_iter", "yyjson_8h.html#structyyjson__arr__iter", "yyjson_8h_structyyjson__arr__iter" ],
    [ "yyjson_doc", "yyjson_8h.html#structyyjson__doc", "yyjson_8h_structyyjson__doc" ],
    [ "yyjson_mut_arr_iter", "yyjson_8h.html#structyyjson__mut__arr__iter", "yyjson_8h_structyyjson__mut__arr__iter" ],
    [ "yyjson_mut_doc", "yyjson_8h.html#structyyjson__mut__doc", "yyjson_8h_structyyjson__mut__doc" ],
    [ "yyjson_mut_obj_iter", "yyjson_8h.html#structyyjson__mut__obj__iter", "yyjson_8h_structyyjson__mut__obj__iter" ],
    [ "yyjson_mut_val", "yyjson_8h.html#structyyjson__mut__val", "yyjson_8h_structyyjson__mut__val" ],
    [ "yyjson_obj_iter", "yyjson_8h.html#structyyjson__obj__iter", "yyjson_8h_structyyjson__obj__iter" ],
    [ "yyjson_patch_err", "yyjson_8h.html#structyyjson__patch__err", "yyjson_8h_structyyjson__patch__err" ],
    [ "yyjson_ptr_ctx", "yyjson_8h.html#structyyjson__ptr__ctx", "yyjson_8h_structyyjson__ptr__ctx" ],
    [ "yyjson_ptr_err", "yyjson_8h.html#structyyjson__ptr__err", "yyjson_8h_structyyjson__ptr__err" ],
    [ "yyjson_read_err", "yyjson_8h.html#structyyjson__read__err", "yyjson_8h_structyyjson__read__err" ],
    [ "yyjson_str_chunk", "yyjson_8h.html#structyyjson__str__chunk", null ],
    [ "yyjson_str_pool", "yyjson_8h.html#structyyjson__str__pool", null ],
    [ "yyjson_val", "yyjson_8h.html#structyyjson__val", "yyjson_8h_structyyjson__val" ],
    [ "yyjson_val_chunk", "yyjson_8h.html#structyyjson__val__chunk", null ],
    [ "yyjson_val_pool", "yyjson_8h.html#structyyjson__val__pool", null ],
    [ "yyjson_val_uni", "yyjson_8h.html#unionyyjson__val__uni", null ],
    [ "yyjson_write_err", "yyjson_8h.html#structyyjson__write__err", "yyjson_8h_structyyjson__write__err" ]
];