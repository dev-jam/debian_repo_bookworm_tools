var yyjson_8h_structyyjson__arr__iter =
[
    [ "cur", "yyjson_8h.html#a7445de186190ceef09c5be6d589e6a65", null ],
    [ "idx", "yyjson_8h.html#a1dbfcf575677cf45d7b1e1bef3de9c91", null ],
    [ "max", "yyjson_8h.html#a4c9dc89d29725de644b1d9b801aa28ff", null ]
];