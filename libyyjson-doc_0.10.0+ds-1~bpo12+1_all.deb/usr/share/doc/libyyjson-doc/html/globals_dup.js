var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "y", "globals_y.html", null ]
];